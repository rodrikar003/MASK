var AM = new AssetManager();

//BACKGROUND CODE ****
function Background(game, spritesheet, x, y) {
    
    this.x = x;
    this.y = y;
    this.spritesheet = spritesheet;
    this.game = game;
    this.ctx = game.ctx;
    this.panX= 350;
    this.panY= 350;
};

Background.prototype.draw = function () {
    // console.log(this.x + "  " + this.y);
    this.ctx.drawImage(this.spritesheet, this.x, this.y);
    // var viewPort = Scrolling(this.panX, this.panY, this.x, this.y);// car coords
    
    // this.ctx.drawImage(this.spritesheet, viewPort.xAXIS, viewPort.yAXIS,
    //                    750,750, 0,0, 1681,911);
    // this.panX++;
    this.panY++;
};

Background.prototype.update = function () {
};

//750 x 750 
function Scrolling(carX, carY, sheetWidth, sheetHeight) {
    this.carX = carX;
    this.carY = carY;
    this.sheetWidth;
    this.sheetHeight;
    var panX = carX - 350;
    if (this.panX < 0) {
        this.panX = 0;
    } 
    
    var panY = carY - 350;
    if (this.panY > 911) {
        this.panY = 0;
    } 
    return {xAXIS: panX, yAXIS: panY};
}

Scrolling.prototype.draw = function () {
    Background.ctx.spriteSheet
}

/*
var tilePaths
8 tiles these are the building coords to be excluded
[[{}],
[{}],
[{}],
[{xLeft: 270 , xRight: 1365, YTop: 0, YBottom: 410},{1000,1360,560,915}],
[{1000,1360,0,250}, {270,1365,610,925}, {1490,1640,580,925}],
[{}],
[{}],
[{}]]
*/ 
// independent functions to be built in
// tileNum is current tile the car is driving on
function canDrive(X, Y, tileNum){
    this.X = X; // need to take in count width and height 
    this.Y = Y;
    this.tileNum = tileNum;
    this.canDrive = true;
    for (var i = 0; i < tilePaths.length, i++;) {
        var coords = tilePaths[i];
        if ((this.X >= coords.xLeft && this.X <= coords.xRight) &&
            (this.Y >= coords.yTop && this.Y <= coords.yBottom)) {
                canDrive = false;
                break;
            }
    }
    return this.canDrive;
}


//**** 
AM.queueDownload("./img/5.jpg");
AM.queueDownload("./img/4.jpg");



AM.downloadAll(function () {
    var canvas = document.getElementById("gameWorld");
    var ctx = canvas.getContext("2d");

    var gameEngine = new GameEngine();
    gameEngine.init(ctx);
    gameEngine.start();
 
    gameEngine.addEntity(new Background(gameEngine, AM.getAsset("./img/5.jpg"),0,0));
    gameEngine.addEntity(new Background(gameEngine, AM.getAsset("./img/4.jpg"),0,911));
    

});